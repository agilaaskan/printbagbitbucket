<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\Bndes\Observer;

use Magento\Framework\Event\Observer;
use Magento\Payment\Observer\AbstractDataAssignObserver;
use Magento\Quote\Api\Data\PaymentInterface;

class DataAssignObserver extends AbstractDataAssignObserver
{
    const BNDES_COMPANY = 'bndes_company';
    const BNDES_CNPJ = 'bndes_cnpj';
    const BNDES_CARD_NUMBER = 'bndes_card_number';
    const BNDES_VALID_THRU = 'bndes_valid_thru';
    const BNDES_SECURITY_CODE = 'bndes_security_code';
    const BNDES_INSTALLMENTS = 'bndes_installments';

    /**
     * @var array
     */
    protected $additionalInformationList = [
        self::BNDES_COMPANY,
        self::BNDES_CNPJ,
        self::BNDES_CARD_NUMBER,
        self::BNDES_VALID_THRU,
        self::BNDES_SECURITY_CODE,
        self::BNDES_INSTALLMENTS,
    ];

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer): void
    {
        $data = $this->readDataArgument($observer);

        $additionalData = $data->getData(PaymentInterface::KEY_ADDITIONAL_DATA);
        if (!is_array($additionalData)) {
            return;
        }

        $paymentInfo = $this->readPaymentModelArgument($observer);

        foreach ($this->additionalInformationList as $additionalInformationKey) {
            if (isset($additionalData[$additionalInformationKey])) {
                $paymentInfo->setAdditionalInformation(
                    $additionalInformationKey,
                    $additionalData[$additionalInformationKey]
                );
            }
        }
    }
}