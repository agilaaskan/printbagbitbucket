<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\Bndes\Block\Form;

use Magento\Payment\Block\Form;

class Bndes extends Form
{
    /**
     * @var string
     */
    protected $_template = 'Hibrido_Bndes::form/bndes.phtml';
}