<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Hibrido\Bndes\Block\Info;

use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Block\Info;

class Bndes extends Info
{
    /**
     * @var string
     */
    protected $_template = 'Hibrido_Bndes::info/bndes.phtml';

    /**
     * @return string
     */
    public function getPaymentMethodTitle(): string
    {
        try {
            /** @noinspection PhpUndefinedMethodInspection */
            $storeId = $this->getInfo()->getOrder()->getStoreId();
        } catch (LocalizedException $e) {
            $storeId = null;
        }

        return $this->getMethod()->getConfigData('title', $storeId);
    }

    /**
     * @return string
     */
    public function getBndesCompany(): string
    {
        return $this->getAdditionalData('bndes_company');
    }

    /**
     * @return string
     */
    public function getBndesCnpj(): string
    {
        return $this->getAdditionalData('bndes_cnpj');
    }

    /**
     * @return string
     */
    public function getBndesCardNumber(): string
    {
        return $this->getAdditionalData('bndes_card_number');
    }

    /**
     * @return string
     */
    public function getBndesValidThru(): string
    {
        return $this->getAdditionalData('bndes_valid_thru');
    }

    /**
     * @return string
     */
    public function getBndesSecurityCode(): string
    {
        return $this->getAdditionalData('bndes_security_code');
    }

    /**
     * @return string
     */
    public function getBndesInstallments(): string
    {
        return $this->getAdditionalData('bndes_installments');
    }

    /**
     * @param string $field
     * @param string $default
     * @return string
     */
    private function getAdditionalData(string $field, string $default = ''): string
    {
        try {
            $info = $this->getInfo();
        } catch (LocalizedException $e) {
            return $default;
        }

        return $info->getAdditionalInformation($field) ?: $default;
    }
}
