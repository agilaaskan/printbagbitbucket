/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'Magento_Checkout/js/view/payment/default',
    'jquery',
    'mage/validation'
], function (Component, $) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Hibrido_Bndes/payment/bndes',
            bndesFormId: 'bndes-form',
            bndesCompany: null,
            bndesCnpj: null,
            bndesCardNumber: null,
            bndesValidThru: null,
            bndesSecurityCode: null,
            bndesInstallments: null,
        },

        /**
         * @return {Object}
         */
        getData: function () {
            return {
                'method': this.item.method,
                'additional_data': {
                    'bndes_company': this.bndesCompany,
                    'bndes_cnpj': this.bndesCnpj,
                    'bndes_card_number': this.bndesCardNumber,
                    'bndes_valid_thru': this.bndesValidThru,
                    'bndes_security_code': this.bndesSecurityCode,
                    'bndes_installments': this.bndesInstallments
                }
            };
        },

        /**
         * @return {boolean}
         */
        validate: function () {
            let $bndesForm = $(`#${this.bndesFormId}`);

            if (!$bndesForm.length) {
                return false;
            }

            return $bndesForm.validation().valid();
        }
    });
});
