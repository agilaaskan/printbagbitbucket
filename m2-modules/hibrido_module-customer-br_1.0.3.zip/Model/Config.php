<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\CustomerBR\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class Config
{
    /**
     * XML Config Paths
     */
    const XML_CONFIG_TAXVAT_UNIQUE_PATH = 'customer/address/taxvat_unique';

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @return bool
     */
    public function isTaxvatUnique(): bool
    {
        return $this->scopeConfig->isSetFlag(self::XML_CONFIG_TAXVAT_UNIQUE_PATH, ScopeInterface::SCOPE_STORE);
    }
}