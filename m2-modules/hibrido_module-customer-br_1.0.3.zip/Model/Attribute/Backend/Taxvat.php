<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\CustomerBR\Model\Attribute\Backend;

use Hibrido\CustomerBR\Model\Config;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\Backend\AbstractBackend;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Exception\LocalizedException;

class Taxvat extends AbstractBackend
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var FilterGroupBuilder
     */
    private $filterGroupBuilder;

    /**
     * @var FilterBuilder
     */
    private $filterBuilder;

    /**
     * @param Config $config
     * @param CustomerRepositoryInterface $customerRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param FilterGroupBuilder $filterGroupBuilder
     * @param FilterBuilder $filterBuilder
     */
    public function __construct(
        Config $config,
        CustomerRepositoryInterface $customerRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterGroupBuilder $filterGroupBuilder,
        FilterBuilder $filterBuilder
    ) {
        $this->config = $config;
        $this->customerRepository = $customerRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterGroupBuilder = $filterGroupBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * @return AbstractBackend
     * @throws LocalizedException
     * @var Customer $customer
     */
    public function beforeSave($customer)
    {
        $that = parent::beforeSave($customer);

        //If we don't have a Taxvat on the object we can just bail out.
        /** @noinspection PhpUndefinedMethodInspection */
        if (!$customer->getTaxvat()) {
            return $that;
        }

        //If Taxvat is not unique we can just bail out.
        if (!$this->config->isTaxvatUnique()) {
            return $that;
        }

        //Create initial filters.
        $filterGroups = [];

        /** @noinspection PhpUndefinedMethodInspection */
        $filterGroups[] = $this->filterGroupBuilder
            ->addFilter(
                $this->filterBuilder
                    ->setField('taxvat')
                    ->setValue($customer->getTaxvat())
                    ->setConditionType('eq')
                    ->create()
            )
            ->addFilter(
                $this->filterBuilder
                    ->setField('taxvat')
                    ->setValue(preg_replace('#\D#', '', $customer->getTaxvat()))
                    ->setConditionType('eq')
                    ->create()
            )
            ->create();

        //If we already have a customer we need to take it out of query.
        if ($customer->getEntityId()) {
            $filterGroups[] = $this->filterGroupBuilder
                ->addFilter(
                    $this->filterBuilder
                        ->setField('entity_id')
                        ->setValue($customer->getEntityId())
                        ->setConditionType('neq')
                        ->create()
                )
                ->create();
        }

        //If the config sharing is website we need to scope it to website level. (PS: getWebsiteId can be 0)
        if ($customer->getSharingConfig()->isWebsiteScope() && $customer->getWebsiteId() !== null) {
            $filterGroups[] = $this->filterGroupBuilder
                ->addFilter(
                    $this->filterBuilder
                        ->setField('website_id')
                        ->setValue($customer->getWebsiteId())
                        ->setConditionType('eq')
                        ->create()
                )
                ->create();
        }

        //Get customers with conditions above.
        $searchResult = $this->customerRepository->getList(
            $this->searchCriteriaBuilder
                ->setFilterGroups($filterGroups)
                ->create()
        );

        //Check to see if this Taxvat is unique.
        if ($searchResult->getTotalCount() >= 1) {
            throw new LocalizedException(__('An account with the same Tax/VAT Number already exists.'));
        }

        return $that;
    }
}